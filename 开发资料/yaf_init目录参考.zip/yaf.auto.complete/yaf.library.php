yaf.library
yaf.action_prefer
yaf.lowcase_path	
yaf.use_spl_autoload	
yaf.forward_limit	
yaf.name_suffix	
yaf.name_separator	
yaf.cache_config	
yaf.environ	product	
yaf.use_namespace