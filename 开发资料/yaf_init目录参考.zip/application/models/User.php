<?php 
class UserModel{

    public function init()
    {
        echo 'init';
    }
}

 ?>