<?php

class UserController extends Yaf_Controller_Abstract{
    public function indexAction()
    {
        echo "UserController index function call....";
        return false;
    }
}
