<?php

class BackController extends Yaf_Controller_Abstract
{
    public function indexAction()
    {

        echo 'string';
        return false;

    }
    
}