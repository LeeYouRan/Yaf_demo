<?php 
/**
 * query类
 */
class Db_Query
{
    /**
     * summary
     */
    public function __construct()
    {
        	echo 'db init';
    }

    public function getUserInfo()
    {
        echo 'getUserinfo call....';
    }
}

 ?>