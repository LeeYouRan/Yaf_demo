<?php 
/**
 * summary
 */
class Dao_Mysql_Query
{
    /**
     * summary
     */
    public function __construct()
    {
        echo 'Dao_Mysql_Query';
    }
}

 ?>