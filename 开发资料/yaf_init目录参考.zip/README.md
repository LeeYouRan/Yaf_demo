# yaf_init
this is yaf application init...


## yaf框架目录结构
```html
application
│  │  Bootstrap.php
│  ├─common
│  │      functions.php
│  ├─controllers
│  │      Index.php
│  ├─library
│  ├─models
│  │  │  User.php
│  │  │
│  │  └─Db
│  │          Medoo.php
│  ├─modules
│  │  └─Admin
│  │      ├─controllers
│  │      │      Back.php
│  │      └─views
│  ├─plugins
│  └─views
│      └─index
│              index.phtml
├─conf
│      application.ini
│
└─public
        index.php
```
